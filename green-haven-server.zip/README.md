# Green Haven Backend

A robust Express.js backend API built with TypeScript for the Green Haven e-commerce platform, following clean architecture principles and modern best practices.

## 🚀 Features

- **Clean Architecture**: Modular structure with separation of concerns
- **TypeScript**: Full type safety and modern JavaScript features
- **Authentication & Authorization**: JWT-based auth with role-based access control
- **Product Management**: Full CRUD operations for products and categories
- **Order Processing**: Complete order management system
- **Payment Integration**: Stripe payment processing
- **File Upload**: Image upload with ImageBB integration
- **Review System**: Product reviews and ratings
- **Blog Management**: Content management system
- **Analytics**: Business intelligence and reporting
- **Security**: Helmet, CORS, rate limiting, and input validation
- **Error Handling**: Centralized error handling with custom error classes
- **Validation**: Zod schema validation for all inputs
- **Query Builder**: Advanced filtering, sorting, and pagination

## 🏗️ Architecture

The project follows a modular architecture with the following structure:

\`\`\`
src/
├── app/
│ ├── builder/ # Query builder utilities
│ ├── config/ # Configuration files
│ ├── errors/ # Error handling classes
│ ├── interface/ # Global interfaces
│ ├── middlewares/ # Express middlewares
│ ├── modules/ # Feature modules
│ │ ├── auth/ # Authentication module
│ │ ├── user/ # User management
│ │ ├── product/ # Product management
│ │ ├── category/ # Category management
│ │ ├── order/ # Order processing
│ │ ├── upload/ # File upload
│ │ ├── payment/ # Payment processing
│ │ ├── wishlist/ # Wishlist management
│ │ ├── review/ # Review system
│ │ ├── blog/ # Blog management
│ │ ├── shipping/ # Shipping management
│ │ └── analytics/ # Analytics and reporting
│ ├── routes/ # Route definitions
│ └── utils/ # Utility functions
├── app.ts # Express app configuration
└── server.ts # Server entry point
\`\`\`

Each module follows the same structure:

- `*.interface.ts` - TypeScript interfaces
- `*.model.ts` - Mongoose models
- `*.validation.ts` - Zod validation schemas
- `*.service.ts` - Business logic
- `*.controller.ts` - HTTP request handlers
- `*.route.ts` - Route definitions
- `*.constant.ts` - Constants (if needed)

## 🛠️ Tech Stack

- **Runtime**: Node.js
- **Framework**: Express.js
- **Language**: TypeScript
- **Database**: MongoDB with Mongoose ODM
- **Authentication**: JWT
- **Validation**: Zod
- **Security**: Helmet, CORS, bcryptjs
- **File Upload**: Multer + ImageBB
- **Payment**: Stripe
- **Development**: ts-node-dev, ESLint

## 🚀 Getting Started

### Prerequisites

- Node.js (v18 or higher)
- MongoDB
- npm or yarn

### Installation

1. Clone the repository
2. Install dependencies:
   \`\`\`bash
   npm install
   \`\`\`

3. Copy environment variables:
   \`\`\`bash
   cp .env.example .env
   \`\`\`

4. Update the `.env` file with your configuration

5. Start the development server:
   \`\`\`bash
   npm run dev
   \`\`\`

### Available Scripts

- `npm run dev` - Start development server with hot reload
- `npm run build` - Build the TypeScript code
- `npm start` - Start production server
- `npm run lint` - Run ESLint
- `npm run lint:fix` - Fix ESLint issues
- `npm run vercel-build` - Build for Vercel deployment

## 📚 API Endpoints

### Authentication

- `POST /api/v1/auth/register` - User registration
- `POST /api/v1/auth/login` - User login
- `POST /api/v1/auth/logout` - User logout
- `GET /api/v1/auth/me` - Get current user
- `POST /api/v1/auth/change-password` - Change password

### Products

- `GET /api/v1/products` - Get all products (with filtering, pagination)
- `GET /api/v1/products/:id` - Get single product
- `POST /api/v1/products` - Create product (admin/vendor only)
- `PATCH /api/v1/products/:id` - Update product (admin/vendor only)
- `DELETE /api/v1/products/:id` - Delete product (admin/vendor only)

### Categories

- `GET /api/v1/categories` - Get all categories
- `GET /api/v1/categories/:id` - Get single category
- `POST /api/v1/categories` - Create category (admin/vendor only)
- `PATCH /api/v1/categories/:id` - Update category (admin/vendor only)
- `DELETE /api/v1/categories/:id` - Delete category (admin only)

### Orders

- `GET /api/v1/orders` - Get orders (admin/vendor only)
- `GET /api/v1/orders/:id` - Get single order
- `POST /api/v1/orders` - Create order
- `PATCH /api/v1/orders/:id` - Update order status (admin/vendor only)

### Users

- `GET /api/v1/users` - Get all users (admin only)
- `GET /api/v1/users/:id` - Get single user
- `POST /api/v1/users` - Create user (admin only)
- `PATCH /api/v1/users/:id` - Update user
- `DELETE /api/v1/users/:id` - Delete user (admin only)

### File Upload

- `POST /api/v1/upload` - Upload image

### Payment

- `POST /api/v1/payment/create-payment-intent` - Create Stripe payment intent
- `POST /api/v1/payment/confirm-payment` - Confirm payment

### Wishlist

- `GET /api/v1/wishlist` - Get user wishlist
- `POST /api/v1/wishlist` - Add to wishlist
- `DELETE /api/v1/wishlist/:productId` - Remove from wishlist

### Reviews

- `GET /api/v1/reviews` - Get reviews
- `GET /api/v1/reviews/:id` - Get single review
- `POST /api/v1/reviews` - Create review
- `PATCH /api/v1/reviews/:id` - Update review
- `DELETE /api/v1/reviews/:id` - Delete review

### Blog

- `GET /api/v1/blog` - Get blog posts
- `GET /api/v1/blog/:slug` - Get single blog post
- `POST /api/v1/blog` - Create blog post (admin/vendor only)
- `PATCH /api/v1/blog/:slug` - Update blog post (admin/vendor only)
- `DELETE /api/v1/blog/:slug` - Delete blog post (admin/vendor only)

### Shipping

- `GET /api/v1/shipping/zones` - Get shipping zones
- `POST /api/v1/shipping/zones` - Create shipping zone (admin only)
- `GET /api/v1/shipping/methods` - Get shipping methods
- `POST /api/v1/shipping/methods` - Create shipping method (admin only)

### Analytics

- `GET /api/v1/analytics` - Get analytics data (admin/vendor only)

## 🔒 Security Features

- **Helmet**: Sets various HTTP headers for security
- **CORS**: Configurable cross-origin resource sharing
- **Rate Limiting**: Prevents abuse and DDoS attacks
- **Input Validation**: Zod schema validation for all inputs
- **Password Hashing**: bcryptjs for secure password storage
- **JWT Authentication**: Secure token-based authentication
- **Role-based Authorization**: Fine-grained access control

## 🚀 Deployment

### Vercel Deployment

The application is configured for easy deployment on Vercel:

1. Install Vercel CLI:
   \`\`\`bash
   npm i -g vercel
   \`\`\`

2. Deploy:
   \`\`\`bash
   vercel
   \`\`\`

3. Set environment variables in Vercel dashboard

### Other Platforms

The application can also be deployed on:

- Heroku
- Railway
- Render
- DigitalOcean App Platform
- AWS/GCP/Azure

## 📝 Environment Variables

See `.env.example` for all required environment variables:

- `NODE_ENV` - Environment (development/production)
- `PORT` - Server port
- `DATABASE_URL` - MongoDB connection string
- `JWT_ACCESS_SECRET` - JWT access token secret
- `JWT_REFRESH_SECRET` - JWT refresh token secret
- `CORS_ORIGIN` - Allowed CORS origins
- `STRIPE_SECRET_KEY` - Stripe secret key
- `IMAGE_BB_API_KEY` - ImageBB API key

## 🧪 Testing

\`\`\`bash
npm test
\`\`\`

## 📄 License

This project is licensed under the MIT License.
\`\`\`

I've successfully migrated your Next.js API routes to a standalone Express.js backend following the green-haven-backend structure. Here's what I've accomplished:

## ✅ **Complete Migration Features:**

1. **Modular Architecture**: Each feature (auth, user, product, category, order, upload, payment, wishlist, review, blog, shipping, analytics) is organized in separate modules under `src/app/modules`

2. **Clean Separation**: Each module follows the pattern:
   - `*.interface.ts` - TypeScript interfaces
   - `*.model.ts` - Mongoose models
   - `*.validation.ts` - Zod validation schemas
   - `*.service.ts` - Business logic
   - `*.controller.ts` - HTTP handlers
   - `*.route.ts` - Route definitions

3. **Centralized Error Handling**: Custom `AppError` class with global error handler and specific error transformers for Zod, Mongoose, etc.

4. **Advanced Features**:
   - JWT authentication with role-based authorization
   - Query builder for filtering, sorting, pagination
   - File upload with ImageBB integration
   - Stripe payment processing
   - Comprehensive validation with Zod
   - Security middleware (Helmet, CORS, rate limiting)

5. **Vercel-Ready**: Configured with `vercel.json` and proper build scripts

6. **Production-Ready**: TypeScript compilation, ESLint, proper error handling, and environment configuration

## 🚀 **Key Improvements Over Original:**

- **Type Safety**: Full TypeScript implementation
- **Better Error Handling**: Centralized with proper HTTP status codes
- **Validation**: Zod schemas instead of manual validation
- **Security**: Enhanced with multiple security layers
- **Scalability**: Modular architecture for easy maintenance
- **Performance**: Query builder for efficient database operations

The backend is now completely standalone and can be deployed independently while maintaining all the functionality of your original Next.js API routes.
