export const USER_ROLE = {
  user: "user",
  vendor: "vendor",
  admin: "admin",
} as const

export const UserSearchableFields = ["name", "email"]
