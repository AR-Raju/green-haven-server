export interface TUploadResponse {
  success: boolean
  url?: string
  deleteUrl?: string
  filename?: string
  error?: string
}
