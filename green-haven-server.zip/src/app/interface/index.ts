import type { USER_ROLE } from "../modules/user/user.constant"

export type TUserRole = keyof typeof USER_ROLE
